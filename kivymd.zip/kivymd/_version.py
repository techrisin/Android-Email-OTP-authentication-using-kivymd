release = False
__version__ = "2.0.1.dev0"
__hash__ = "Unknown"
__short_hash__ = "Unknown"
__date__ = "2024-03-11"
